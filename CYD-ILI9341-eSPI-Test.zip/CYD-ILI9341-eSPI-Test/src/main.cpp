
/*******************************************************************
    A touch screen test for the ESP32 Cheap Yellow Display.

    https://github.com/witnessmenow/ESP32-Cheap-Yellow-Display

    If you find what I do useful and would like to support me,
    please consider becoming a sponsor on Github
    https://github.com/sponsors/witnessmenow/

    Written by Brian Lough
    YouTube: https://www.youtube.com/brianlough
    Twitter: https://twitter.com/witnessmenow
 *******************************************************************/

// Make sure to copy the UserSetup.h file into the library as
// per the Github Instructions. The pins are defined in there.

///=================================================================
///@brief Headers
///=================================================================
#include <Arduino.h>
#include <SD.h>
#include <FS.h>
#include <SPI.h>
#include <lvgl.h>
#include "ui.h"
#include "images.h"
// ----------------------------
// Additional Libraries - each one of these will need to be installed.
// ----------------------------

#include <XPT2046_Touchscreen.h>
// A library for interfacing with the touch screen
//
// Can be installed from the library manager (Search for "XPT2046")
//https://github.com/PaulStoffregen/XPT2046_Touchscreen

#include <TFT_eSPI.h>
// A library for interfacing with LCD displays
//
// Can be installed from the library manager (Search for "TFT_eSPI")
//https://github.com/Bodmer/TFT_eSPI
///=================================================================
///@brief Variables
///=================================================================
uint8_t imageBuffer[1024]; // Adjust buffer size as needed
static lv_disp_draw_buf_t draw_buf;
static lv_color_t buf[TFT_WIDTH * TFT_HEIGHT / 10];

///=================================================================
///@brief Classes
///=================================================================
SPIClass mySpi = SPIClass(VSPI);
XPT2046_Touchscreen ts(XPT2046_CS, XPT2046_IRQ);
TFT_eSPI tft = TFT_eSPI();
File imageFile;

///=================================================================
///@brief Prototypes
///=================================================================
void InitTFT();
void printTouchToSerial(TS_Point p);
void printTouchToDisplay(TS_Point p);
void TSLoop();
void InitLVGL();
void my_touchpad_read(lv_indev_drv_t *indev_drv, lv_indev_data_t *data);
void my_disp_flush(lv_disp_drv_t *disp_drv, const lv_area_t *area, lv_color_t *color_p);
void Init_SD();
///=================================================================
///@brief setup()
///=================================================================
void setup()
 {
  Serial.begin(115200);

  InitTFT();
  InitLVGL();
  Init_SD();
}

///=================================================================
///@brief loop()
///=================================================================
void loop()
 {
  lv_timer_handler(); /* let the GUI do its work */
  delay(5);
}

///=================================================================
///@brief InitTFT()
///=================================================================
void InitTFT()
{

  // Start the SPI for the touch screen and init the TS library
  mySpi.begin(XPT2046_CLK, XPT2046_MISO, XPT2046_MOSI, XPT2046_CS);
  // ts.begin(SPI1);
  ts.begin(mySpi);
  ts.setRotation(1);

  // Start the tft display and set it to black
  tft.init();
  tft.setRotation(1); //This is the display in landscape
  tft.invertDisplay(true);
  // Clear the screen before writing to it
  tft.fillScreen(TFT_GREENYELLOW);

}
///=================================================================
///@brief printTouchToSerial(TS_Point p) 
///=================================================================
void printTouchToSerial(TS_Point p) 
{
  Serial.print("Pressure = ");
  Serial.print(p.z);
  Serial.print(", x = ");
  Serial.print(p.x);
  Serial.print(", y = ");
  Serial.print(p.y);
  Serial.println();
}

///=================================================================
///@brief printTouchToDisplay(TS_Point p)
///=================================================================
void printTouchToDisplay(TS_Point p)
 {

  // Clear screen first
  tft.fillScreen(TFT_BLACK);
  tft.setTextColor(TFT_GREENYELLOW, TFT_BLACK);

  int x = 320 / 2; // center of display
  int y = 100;
  int fontSize = 2;

  String temp = "Pressure = " + String(p.z);
  tft.drawCentreString(temp, x, y, fontSize);

  y += 16;
  temp = "X = " + String(p.x);
  tft.drawCentreString(temp, x, y, fontSize);

  y += 16;
  temp = "Y = " + String(p.y);
  tft.drawCentreString(temp, x, y, fontSize);
}

///=================================================================
///@brief InitLVGL()
///=================================================================
void InitLVGL()
    {

     lv_init();
     lv_disp_draw_buf_init(&draw_buf, buf, NULL, TFT_WIDTH * TFT_HEIGHT / 10);
    /*Initialize the display*/
    static lv_disp_drv_t disp_drv;
    lv_disp_drv_init(&disp_drv);
    /*Change the following line to your display resolution*/
    disp_drv.hor_res = TFT_WIDTH;
    disp_drv.ver_res = TFT_HEIGHT;
    disp_drv.flush_cb = my_disp_flush;
    disp_drv.draw_buf = &draw_buf;
    lv_disp_drv_register(&disp_drv);

    /*Initialize the (dummy) input device driver*/
    static lv_indev_drv_t indev_drv;
    lv_indev_drv_init(&indev_drv);
    indev_drv.type = LV_INDEV_TYPE_POINTER;
    indev_drv.read_cb = my_touchpad_read;
    lv_indev_drv_register(&indev_drv);

    /* Uncomment to create simple label */
    // lv_obj_t *label = lv_label_create( lv_scr_act() );
    // lv_label_set_text( label, "Hello Ardino and LVGL!");
    // lv_obj_align( label, LV_ALIGN_CENTER, 0, 0 );
   // ui_init();
    }

 
 
///=================================================================
///@brief my_touchpad_read(lv_indev_drv_t *indev_drv, lv_indev_data_t *data)
///=================================================================
void my_touchpad_read(lv_indev_drv_t *indev_drv, lv_indev_data_t *data)
{
    uint16_t touchX, touchY;
    bool touched = (ts.tirqTouched() && ts.touched()); // this is the version needed for XPT2046 touchscreen

    if (!touched)
    {
        data->state = LV_INDEV_STATE_REL;
    }
    else
    {
        // the following three lines are specific for using the XPT2046 touchscreen
        TS_Point p = ts.getPoint();
        touchX = map(p.x, 200, 3700, 1, TFT_WIDTH);  /* Touchscreen X calibration */
        touchY = map(p.y, 240, 3800, 1, TFT_HEIGHT); /* Touchscreen X calibration */
     
    }
}

///=================================================================
///@brief my_disp_flush(lv_disp_drv_t *disp_drv, const lv_area_t *area, lv_color_t *color_p)
///=================================================================
void my_disp_flush(lv_disp_drv_t *disp_drv, const lv_area_t *area, lv_color_t *color_p)
{
    uint32_t w = (area->x2 - area->x1 + 1);
    uint32_t h = (area->y2 - area->y1 + 1);

    tft.startWrite();
    tft.setAddrWindow(area->x1, area->y1, w, h);
    tft.pushColors((uint16_t *)&color_p->full, w * h, true);
    tft.endWrite();

    lv_disp_flush_ready(disp_drv);
}


///=================================================================
///@brief uint8_t *read_image_from_sd(const char *filename) 
///=================================================================
uint8_t *read_image_from_sd(const char *filename) 
{
  File ImageFile = SD.open(filename);
  if (ImageFile) {
   Serial.printf("File : Success: %s \n", filename);
} else {
  // Datei nicht gefunden, Fehlermeldung anzeigen
  Serial.printf("File : Error: %s", filename);
  lv_obj_t *label = lv_label_create(lv_scr_act());
  lv_label_set_text(label, "File : Error");
  lv_obj_align(label, LV_ALIGN_CENTER, 0, 0);
  lv_label_set_text(label, filename);
  lv_obj_align(label, LV_ALIGN_CENTER, 20, 0);
}

  if (!ImageFile) {
    Serial.println("Error opening file");
    return NULL;
  }

  uint32_t fileSize = ImageFile.size();
  uint8_t *buffer = (uint8_t*)malloc(fileSize);
  if (!buffer) {
    Serial.println("Memory allocation failed");
    ImageFile.close();
    return NULL;
  }

  uint32_t bytesRead = 0;
  while (bytesRead < fileSize) {
    bytesRead += ImageFile.read(buffer + bytesRead, fileSize - bytesRead);
  }

  ImageFile.close();
  
  return buffer;
}

///=================================================================
///@brief load_image_from_sd(const char *filename, int x, int y) 
///=================================================================
void load_image_from_sd(const char *filename, int x, int y) 
{

    uint8_t *image_data = read_image_from_sd(filename);

    if (image_data) {
        lv_img_dsc_t img_dsc;
        img_dsc.data = image_data;
        img_dsc.header.always_zero = 0;
        img_dsc.header.w = 50; // Replace with actual image width
        img_dsc.header.h = 50; // Replace with actual image height
        img_dsc.header.cf = LV_IMG_CF_RGB565; // Adjust color format as needed

        lv_obj_t *img = lv_img_create(lv_scr_act());
        lv_img_set_src(img, &img_dsc);
        lv_obj_align(img, LV_ALIGN_OUT_TOP_LEFT, x, y);
       lv_task_handler();
    }
}



///=================================================================
///@brief Init_SD()
///=================================================================
void Init_SD()
{
if (!SD.begin(SD_CS))
{
  Serial.println("SD Card Init : Error");
  return;
}
else
Serial.println("SD Card Init : Success");
load_image_from_sd("/icon50/storm-night.jpg", 20,40);
load_image_from_sd("/icon50/Storm.jpg", 20,100);
load_image_from_sd("/icon50/fog-day.jpg", 50,20);

}