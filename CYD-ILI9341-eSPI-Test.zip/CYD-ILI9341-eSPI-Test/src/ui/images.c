#include "images.h"

const ext_img_desc_t images[4] = {
    { "Image_Hand", &img_image_hand },
    { "Image Clear", &img_image_clear },
    { "Rain", &img_rain },
    { "Image Rainy Day", &img_image_rainy_day },
    

};
