#include <string.h>

#include "screens.h"
#include "images.h"
#include "fonts.h"
#include "actions.h"
#include "vars.h"
#include "styles.h"
#include "ui.h"

#include <string.h>

objects_t objects;
lv_obj_t *tick_value_change_obj;


uint8_t *read_image_from_sd(const char *filename, uint32_t *size) {
    // ... implementation to read image data from SD card
    // ... and store it in a buffer
}


void load_image_from_sd(const char *filename) {
    uint32_t image_size;
    uint8_t *image_data = read_image_from_sd(filename, &image_size);

    if (image_data) {
        lv_img_dsc_t img_dsc;
        img_dsc.data = image_data;
        img_dsc.header.always_zero = 0;
        img_dsc.header.w = 50; // Replace with actual image width
        img_dsc.header.h = 50; // Replace with actual image height
        img_dsc.header.cf = LV_IMG_CF_TRUE_COLOR; // Adjust color format as needed

        lv_obj_t *img = lv_img_create(lv_scr_act());
        lv_img_set_src(img, &img_dsc);
    }
}


void create_screen_main() {
    lv_obj_t *obj = lv_obj_create(0);
    objects.main = obj;
    lv_obj_set_pos(obj, 0, 0);
    lv_obj_set_size(obj, 320, 240);
    {
        lv_obj_t *parent_obj = obj;
        {
            lv_obj_t *obj = lv_label_create(parent_obj);
            lv_obj_set_pos(obj, 356, 232);
            lv_obj_set_size(obj, LV_SIZE_CONTENT, LV_SIZE_CONTENT);
            lv_label_set_text(obj, "Hello, world!");
        }
        {
            // _Image_Hand
            lv_obj_t *obj = lv_img_create(parent_obj);
            objects._image_hand = obj;
            lv_obj_set_pos(obj, 59, 14);
            lv_obj_set_size(obj, LV_SIZE_CONTENT, LV_SIZE_CONTENT);
            lv_img_set_src(obj, &img_image_hand);
        }
        {
            // Image Sun
            lv_obj_t *obj = lv_img_create(parent_obj);
            objects._image_rain = obj;
            lv_obj_set_pos(obj, 109, 50);
            lv_obj_set_size(obj, LV_SIZE_CONTENT, LV_SIZE_CONTENT);
            lv_img_set_src(obj, &img_rain);
        }
        {
                // Image Sun
            lv_obj_t *obj = lv_img_create(parent_obj);
            objects._image_rainy_day = obj;
            lv_obj_set_pos(obj, 200, 100);
            lv_obj_set_size(obj, LV_SIZE_CONTENT, LV_SIZE_CONTENT);
            lv_img_set_src(obj, &img_image_rainy_day);
        }
        {
//            lv_img_set_src(img_replace, "S:path/to/picture.jpg");
            lv_obj_t * img = lv_img_create(lv_scr_act());

            // Bildquelle zuweisen
         //   lv_img_set_src(img, img_replace);

            // Bild positionieren und skalieren (optional)
            lv_obj_align(img, LV_ALIGN_CENTER, 0, 0);
            lv_obj_set_width(img, 100);
            lv_obj_set_height(img, 100);

        }
    }
}

void tick_screen_main() {
}


void create_screens() {
    lv_disp_t *dispp = lv_disp_get_default();
    lv_theme_t *theme = lv_theme_default_init(dispp, lv_palette_main(LV_PALETTE_BLUE), lv_palette_main(LV_PALETTE_RED), false, LV_FONT_DEFAULT);
    lv_disp_set_theme(dispp, theme);
    
    create_screen_main();
}

typedef void (*tick_screen_func_t)();

tick_screen_func_t tick_screen_funcs[] = {
    tick_screen_main,
};

void tick_screen(int screen_index) {
    tick_screen_funcs[screen_index]();
}
